package Classes;

import java.util.ArrayList;
import java.util.List;

public class Estabelecimento {
    private String nome;
    private List<Alimento> alimentosExcedentes;

    public Estabelecimento(String nome) {
        this.nome = nome;
        this.alimentosExcedentes = new ArrayList<>();
    }

    public void adicionarAlimentoExcedente(Alimento alimento) {
        alimentosExcedentes.add(alimento);
    }

    public List<Alimento> getAlimentosExcedentes() {
        return alimentosExcedentes;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    /**
     * Retorna a quantidade total de alimentos excedentes.
     */
    public int getQuantidadeTotalAlimentosExcedentes() {
        int quantidadeTotal = 0;
        for (Alimento alimento : alimentosExcedentes) {
            quantidadeTotal += alimento.getQuantidadeExcedente();
        }
        return quantidadeTotal;
    }
    
    /**
     * Verifica se um determinado alimento está presente nos alimentos excedentes.
     * @param nomeAlimento o nome do alimento a ser verificado
     * @return true se o alimento está presente, false caso contrário
     */
    public boolean verificarAlimentoExcedente(String nomeAlimento) {
        for (Alimento alimento : alimentosExcedentes) {
            if (alimento.getNome().equalsIgnoreCase(nomeAlimento)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Calcula a média de quantidade excedente dos alimentos.
     * @return a média de quantidade excedente
     */
    public double calcularMediaQuantidadeExcedente() {
        if (alimentosExcedentes.isEmpty()) {
            return 0.0;
        }
        
        int somaQuantidade = 0;
        for (Alimento alimento : alimentosExcedentes) {
            somaQuantidade += alimento.getQuantidadeExcedente();
        }
        
        return (double) somaQuantidade / alimentosExcedentes.size();
    }
    
    /**
     * Adiciona um alimento excedente com quantidade especificada.
     * Este método é uma sobrecarga do método adicionarAlimentoExcedente.
     * @param nomeAlimento o nome do alimento a ser adicionado
     * @param quantidadeExcedente a quantidade excedente do alimento
     */
    public void adicionarAlimentoExcedente(String nomeAlimento, int quantidadeExcedente) {
        Alimento alimento = new AlimentoNaoPerecivel(nomeAlimento, quantidadeExcedente, nomeAlimento);
        alimentosExcedentes.add(alimento);
    }
    
    /**
     * Calcula o valor total dos alimentos excedentes com base em um valor unitário fornecido.
     * @param valorUnitario o valor unitário dos alimentos
     * @return o valor total dos alimentos excedentes
     */
    public double calcularValorTotalExcedente(double valorUnitario) {
        double valorTotal = 0;
        for (Alimento alimento : alimentosExcedentes) {
            valorTotal += alimento.getQuantidadeExcedente() * valorUnitario;
        }
        return valorTotal;
    }
    
    /**
     * Verifica se um determinado alimento perecível está presente nos alimentos excedentes.
     * @param nomeAlimento o nome do alimento a ser verificado
     * @return true se o alimento está presente, false caso contrário
     */
    public boolean verificarAlimentoPerecivel(String nomeAlimento) {
        for (Alimento alimento : alimentosExcedentes) {
            if (alimento instanceof AlimentoPerecivel && alimento.getNome().equalsIgnoreCase(nomeAlimento)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Conta a quantidade de alimentos não perecíveis presentes nos alimentos excedentes.
     * @return a quantidade de alimentos não perecíveis
     */
    public int contarAlimentosNaoPereciveis() {
        int quantidade = 0;
        for (Alimento alimento : alimentosExcedentes) {
            if (alimento instanceof AlimentoNaoPerecivel) {
                quantidade++;
            }
        }
        return quantidade;
    }
}

