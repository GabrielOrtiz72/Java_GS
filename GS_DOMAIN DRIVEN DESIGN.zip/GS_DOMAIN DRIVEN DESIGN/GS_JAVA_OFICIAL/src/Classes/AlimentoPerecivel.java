package Classes;

public class AlimentoPerecivel extends Alimento {
    public AlimentoPerecivel(String nome, int quantidadeExcedente) {
        super(nome, quantidadeExcedente);
    }

    @Override
    public String getTipo() {
        return "Perecível";
    }
}
