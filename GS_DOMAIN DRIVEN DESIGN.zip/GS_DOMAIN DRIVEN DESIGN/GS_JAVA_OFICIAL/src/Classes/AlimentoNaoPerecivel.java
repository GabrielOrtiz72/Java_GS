package Classes;

public class AlimentoNaoPerecivel extends Alimento {
    private String tipo;

    public AlimentoNaoPerecivel(String nome, int quantidadeExcedente, String tipo) {
        super(nome, quantidadeExcedente);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }
}

