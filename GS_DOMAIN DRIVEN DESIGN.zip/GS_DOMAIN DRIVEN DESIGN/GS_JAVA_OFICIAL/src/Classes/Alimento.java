package Classes;

public abstract class Alimento {
    private String nome;
    private int quantidadeExcedente;

    public Alimento(String nome, int quantidadeExcedente) {
        this.nome = nome;
        this.quantidadeExcedente = quantidadeExcedente;
    }

    public String getNome() {
        return nome;
    }

    public int getQuantidadeExcedente() {
        return quantidadeExcedente;
    }

    public void setQuantidadeExcedente(int quantidadeExcedente) {
        this.quantidadeExcedente = quantidadeExcedente;
    }

    public abstract String getTipo();
}
