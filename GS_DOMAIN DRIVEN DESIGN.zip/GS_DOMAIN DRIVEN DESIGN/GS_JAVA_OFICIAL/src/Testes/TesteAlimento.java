package Testes;

import java.util.Scanner;
import Classes.*;
public class TesteAlimento {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Pergunta ao usuário o nome do estabelecimento
        System.out.print("Digite o nome do estabelecimento: ");
        String nomeEstabelecimento = scanner.nextLine();

        // Pergunta ao usuário a quantidade de alimentos excedentes
        System.out.print("Digite a quantidade de alimentos excedentes: ");
        int quantidadeAlimentos = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha pendente

        // Cria uma instância do estabelecimento
        Estabelecimento estabelecimento = new Estabelecimento(nomeEstabelecimento);

        // Pergunta ao usuário os tipos de alimentos
        for (int i = 0; i < quantidadeAlimentos; i++) {
            System.out.print("Digite o nome do alimento " + (i + 1) + ": ");
            String nomeAlimento = scanner.nextLine();

            System.out.print("Digite a quantidade excedente do alimento " + (i + 1) + ": ");
            int quantidadeExcedente = scanner.nextInt();
            scanner.nextLine(); // Consumir a quebra de linha pendente

            System.out.print("O alimento é perecível (S/N)? ");
            String perecivel = scanner.nextLine();

            if (perecivel.equalsIgnoreCase("S")) {
                AlimentoPerecivel alimentoPerecivel = new AlimentoPerecivel(nomeAlimento, quantidadeExcedente);
                estabelecimento.adicionarAlimentoExcedente(alimentoPerecivel);
            } else {
                estabelecimento.adicionarAlimentoExcedente(nomeAlimento, quantidadeExcedente);
            }
        }

        // Exibe as informações do estabelecimento e dos alimentos excedentes
        System.out.println("Estabelecimento: " + estabelecimento.getNome());
        System.out.println("Alimentos excedentes:");
        for (Alimento alimento : estabelecimento.getAlimentosExcedentes()) {
            System.out.println("- " + alimento.getNome() + " (Quantidade excedente: " + alimento.getQuantidadeExcedente() + ")");
        }

        // Chamada dos métodos adicionais
        System.out.println("Quantidade total de alimentos excedentes: " + estabelecimento.getQuantidadeTotalAlimentosExcedentes());
        System.out.print("Digite o nome de um alimento para verificar se está presente: ");
        String nomeAlimento = scanner.nextLine();
        boolean presente = estabelecimento.verificarAlimentoExcedente(nomeAlimento);
        System.out.println("O alimento está presente: " + presente);
        double mediaQuantidadeExcedente = estabelecimento.calcularMediaQuantidadeExcedente();
        System.out.println("Média de quantidade excedente: " + mediaQuantidadeExcedente);
        System.out.print("Digite um valor unitário para calcular o valor total dos alimentos excedentes: ");
        double valorUnitario = scanner.nextDouble();
        double valorTotalExcedente = estabelecimento.calcularValorTotalExcedente(valorUnitario);
        System.out.println("Valor total dos alimentos excedentes: " + valorTotalExcedente);
        System.out.print("Digite o nome de um alimento perecível para verificar se está presente: ");
        String nomeAlimentoPerecivel = scanner.nextLine();
        boolean presentePerecivel = estabelecimento.verificarAlimentoPerecivel(nomeAlimentoPerecivel);
        System.out.println("O alimento perecível está presente: " + presentePerecivel);
        int quantidadeAlimentosNaoPereciveis = estabelecimento.contarAlimentosNaoPereciveis();
        System.out.println("Quantidade de alimentos não perecíveis: " + quantidadeAlimentosNaoPereciveis);

        // Enviar alimentos aos doadores
        System.out.println("Enviando alimentos aos doadores...");
        // Lógica para enviar alimentos aos doadores e ajudar os necessitados
        System.out.println("Alimentos enviados aos doadores e utilizados para ajudar os necessitados.");
    }
}

